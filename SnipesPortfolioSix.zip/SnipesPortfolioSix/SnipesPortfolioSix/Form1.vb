﻿Public Class Form1
    Dim englishToTextese As New Dictionary(Of String, String)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim filedata() As String = IO.File.ReadAllLines("Textese.txt")
        For Each item As String In filedata
            Dim splitstring() As String = item.Split(","c)
            englishToTextese.Add(splitstring(0), splitstring(1))
        Next
    End Sub

    Private Function IsCapitalized(word As String) As Boolean
        If Mid(word, 1, 1) = Mid(word, 1, 1).ToUpper Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function GetPunctuation(word As String) As Tuple(Of String, String)
        Dim result As Tuple(Of String, String)
        If "!':;?/.,".Contains(word.Last()) Then
            result = New Tuple(Of String, String)(Mid(word, 1, word.Length - 1), word.Last)
        Else
            result = New Tuple(Of String, String)(word, "")
        End If
        Return result
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim textese As String = ""
        Dim words() As String = TextBox1.Text.Split(" "c)
        For Each englishWord As String In words
            Dim punctResult As Tuple(Of String, String) = GetPunctuation(englishWord)
            Dim texteseWord As String
            englishWord = punctResult.Item1
            Dim punctuation As String = punctResult.Item2
            If englishToTextese.ContainsKey(englishWord.ToLower) Then
                texteseWord = englishToTextese(englishWord.ToLower)

                If IsCapitalized(englishWord) Then
                    texteseWord = texteseWord.ToUpperInvariant
                End If
                textese = textese & texteseWord & punctuation & " "
            Else
                textese = textese & englishWord & punctuation & " "
            End If
        Next
        TextBox2.Text = textese
    End Sub
End Class
